package com.quentin.is3261.tutorial4

class DataRecord(val courseCode: String, val numberOfStudents: Int, val level: String)