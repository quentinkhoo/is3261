package vian.hello.tut4

import android.provider.BaseColumns

class TableInfo : BaseColumns {

    companion object {
        val TABLE_NAME = "Students"
        val COLUMN_COURSE = "Course Code"
        val COLUMN_NUMOFSTUDENTS = "Number of Students"
        val COLUMN_LEVEL = "Level"
    }

}