package vian.hello.tut4

class DataRecord (val courseCode: String, val numberOfStudents: Int, val studentLevel: String)