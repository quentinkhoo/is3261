package sg.edu.nus.tutorial4

class DataRecord(val courseCode: String, val numberOfStudents: Int, val level: String)