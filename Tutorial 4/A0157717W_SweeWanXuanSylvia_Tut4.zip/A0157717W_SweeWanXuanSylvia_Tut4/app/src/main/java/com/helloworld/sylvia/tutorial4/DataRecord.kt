package com.helloworld.sylvia.tutorial4

class DataRecord(val courseCode: String, val numberOfStudents: Int, val level: String)
